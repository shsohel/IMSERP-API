﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonDAL.Models
{
    public class Thana
    {
        public string Id { get; set; }
        public int DevisionId { get; set; }
        public int DistrictId { get; set; }
        public string Thana1 { get; set; }
    }
}
