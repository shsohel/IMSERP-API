﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonDAL.Models
{
 public   class DistrictUpazila
    {
        public int Id { get; set; }
        public int DistrictId { get; set; }
        public string UpazilaName { get; set; }
    }
}
