﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonDAL.Models
{
  public  class Designation
    {
        public int Id { get; set; }
        public string DesignationName { get; set; }
    }
}
