﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace IMSERP.Migrations.OnlineIdentityDb
{
    public partial class fir656st : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
